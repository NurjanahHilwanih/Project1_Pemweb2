<?php

class BMIPasien{
    public $BMI;
    public $tanggal;
    public $pasien;
}

?>